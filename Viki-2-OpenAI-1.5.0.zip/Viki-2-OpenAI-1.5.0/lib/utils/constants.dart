// ignore_for_file: non_constant_identifier_names

String OPEN_API_KEY = 'OPEN_AI_API_KEY_HERE';

String BASE_URL = 'https://api.openai.com/v1/';
